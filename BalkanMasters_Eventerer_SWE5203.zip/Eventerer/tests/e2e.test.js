const { test, describe, beforeEach, afterEach, beforeAll, afterAll, expect } = require('@playwright/test');
const { chromium } = require('playwright');

const host = 'http://localhost:3000';
const routes = {
    home: host + '/',
    dashboard: host + '/dashboard',
    details: host + '/details/',
};


let browser;
let context;
let page;

let user = {
    email: "",
    password: "123456",
    confirmPass: "123456",
};

let eventName = "";

async function loginUser(page, email, password) {
    await page.goto(routes.home)
    await page.click('text=Login')
    await page.waitForSelector('form')
    await page.locator('#email').fill(email)
    await page.locator('#password').fill(password)
    await page.click('[type="submit"]')
    await expect(page.locator('nav >> text=Logout')).toBeVisible()
}

describe("e2e tests", () => {
    beforeAll(async () => {
        browser = await chromium.launch();
    });

    afterAll(async () => {
        await browser.close();
    });

    beforeEach(async () => {
        context = await browser.newContext();
        page = await context.newPage();
    });

    afterEach(async () => {
        await page.close();
        await context.close();
    });


    describe("authentication", () => {
        test('Register with valid data', async () => {
            await page.goto(routes.home);

            await page.getByRole('link', { name: 'Register' }).click();
            await page.waitForSelector('form.register-form');

            const random = Math.floor(Math.random() * 10000);
            user.email = `User_${random}@gmail.com`;

            await page.locator('form.register-form input[name="email"]').fill(user.email);
            await page.locator('form.register-form input[name="password"]').fill(user.password);
            await page.locator('form.register-form input[name="re-password"]').fill(user.confirmPass);
            await page.locator('form.register-form [type="submit"]').click();

            await expect(page.locator('nav >> text=Logout')).toBeVisible();
            await expect(page).toHaveURL(routes.home);
        });
        test('Login user with valid data', async () => {
            await loginUser(page, user.email, user.password)
            await expect(page.locator('nav >> text=Logout')).toBeVisible()
            expect(page.url()).toBe(routes.home)
        })

        test('Logout user from the app', async () => {
            await loginUser(page, user.email, user.password)
            await page.locator('nav >> text=Logout').click()
            await expect(page.locator('nav >> text=Login')).toBeVisible()
            expect(page.url()).toBe(routes.home)
        })

    });

    describe("navbar", () => {
        test('Navigation for logged-in user', async () => {
            await loginUser(page, user.email, user.password)

            await expect(page.locator('nav >> text=Events')).toBeVisible()
            await expect(page.locator('nav >> text=Add Event')).toBeVisible()
            await expect(page.locator('nav >> text=Logout')).toBeVisible()

            await expect(page.locator('nav >> text=Login')).toBeHidden()
            await expect(page.locator('nav >> text=Register')).toBeHidden()
        })

        test('Navigation for guest user', async () => {
            await page.goto(routes.home)

            await expect(page.locator('nav >> text=Events')).toBeVisible()
            await expect(page.locator('nav >> text=Login')).toBeVisible()
            await expect(page.locator('nav >> text=Register')).toBeVisible()

            await expect(page.locator('nav >> text=Add Event')).toBeHidden()
            await expect(page.locator('nav >> text=Logout')).toBeHidden()
        })
    });

    describe("CRUD", () => {
        beforeEach(async () => {
            await loginUser(page, user.email, user.password)
        })

        test('Add an Event', async () => {
            const rnd = Math.floor(Math.random() * 100000);
            eventName = `Event ${rnd}`;

            await page.getByRole('link', { name: 'Add Event', exact: true }).click();
            await page.waitForSelector('form.create-form');

            await page.locator('form.create-form input[name="name"]').fill(eventName);
            await page.locator('form.create-form input[name="imageUrl"]').fill('https://example.com/event.jpg');
            await page.locator('form.create-form input[name="category"]').fill('Conference');
            await page.locator('form.create-form textarea[name="description"]').fill('Created event description.');
            await page.locator('form.create-form input[name="date"]').fill('2025-10-19');

            await page.locator('form.create-form button[type="submit"]').click();

            await expect(page).toHaveURL(routes.dashboard);
            await expect(page.locator('#dashboard .event .title', { hasText: eventName })).toBeVisible();
        });

        test('Edit an Event', async () => {
            await page.goto(routes.dashboard);
            const card = page.locator('.event', {
                has: page.locator('.title', { hasText: eventName }),
            });
            const detailsLink = card.locator('a.details-btn');
            await detailsLink.evaluate((el) => el.click());

            await expect(page).toHaveURL(/\/details\/.+/);
            await page.waitForSelector('#details');

            await page.locator('#edit-btn').evaluate((el) => el.click());
            await page.waitForSelector('form.edit-form, form');

            eventName = `${eventName}_edited`;
            await page.locator('#name').fill(eventName);
            await page.click('[type="submit"]');

            await expect(page).toHaveURL(/\/details\/.+/);
            await expect(page.locator(`text=${eventName}`)).toBeVisible();
        });

        test('Delete an Event', async () => {
            await page.goto(routes.dashboard);

            const card = page.locator('.event', {
                has: page.locator('.title', { hasText: eventName }),
            });
            const detailsLink = card.locator('a.details-btn');
            await detailsLink.evaluate((el) => el.click());

            await expect(page).toHaveURL(/\/details\/.+/);
            await page.waitForSelector('#details');

            page.once('dialog', (dialog) => dialog.accept());
            await page.locator('#delete-btn').evaluate((el) => el.click());

            await expect(page).toHaveURL(routes.dashboard);
            await expect(page.locator('.event .title', { hasText: eventName })).toHaveCount(0);
        });
    });
});