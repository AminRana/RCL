import sqlite3
import bcrypt
from datetime import datetime
import os

class Database:
    """Database handler for the Digital Library Management System"""
    
    def __init__(self, db_name="digital_library.db"):
        self.db_name = db_name
        self.conn = None
        self.cursor = None
        self.connect()
        self.create_tables()
    
    def connect(self):
        """Establish database connection"""
        self.conn = sqlite3.connect(self.db_name)
        self.cursor = self.conn.cursor()
    
    def create_tables(self):
        """Create all necessary tables"""
        # Users table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Books table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                genre TEXT NOT NULL,
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ''')
        
        # Badges table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS badges (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                badge_type TEXT NOT NULL,
                books_count INTEGER NOT NULL,
                earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ''')
        
        self.conn.commit()
    
    # ==================== USER OPERATIONS ====================
    
    def register_user(self, email, password):
        """Register a new user with hashed password"""
        try:
            # Hash the password
            password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            
            self.cursor.execute(
                'INSERT INTO users (email, password_hash) VALUES (?, ?)',
                (email, password_hash)
            )
            self.conn.commit()
            return True, "Registration successful!"
        except sqlite3.IntegrityError:
            return False, "Email already exists!"
        except Exception as e:
            return False, f"Registration failed: {str(e)}"
    
    def login_user(self, email, password):
        """Authenticate user login"""
        try:
            self.cursor.execute(
                'SELECT id, password_hash FROM users WHERE email = ?',
                (email,)
            )
            result = self.cursor.fetchone()
            
            if result:
                user_id, stored_hash = result
                # Verify password
                if bcrypt.checkpw(password.encode('utf-8'), stored_hash):
                    return True, user_id, "Login successful!"
                else:
                    return False, None, "Invalid password!"
            else:
                return False, None, "Email not found!"
        except Exception as e:
            return False, None, f"Login failed: {str(e)}"
    
    # ==================== BOOK OPERATIONS ====================
    
    def add_book(self, user_id, title, genre):
        """Add a new book to user's library"""
        try:
            self.cursor.execute(
                'INSERT INTO books (user_id, title, genre) VALUES (?, ?, ?)',
                (user_id, title, genre)
            )
            self.conn.commit()
            
            # Check and award badges
            self.check_and_award_badges(user_id)
            
            return True, "Book added successfully!"
        except Exception as e:
            return False, f"Failed to add book: {str(e)}"
    
    def get_user_books(self, user_id):
        """Get all books for a specific user"""
        self.cursor.execute(
            'SELECT id, title, genre, added_at FROM books WHERE user_id = ? ORDER BY added_at DESC',
            (user_id,)
        )
        return self.cursor.fetchall()
    
    def get_recent_books(self, user_id, limit=5):
        """Get recently added books for a user"""
        self.cursor.execute(
            'SELECT id, title, genre, added_at FROM books WHERE user_id = ? ORDER BY added_at DESC LIMIT ?',
            (user_id, limit)
        )
        return self.cursor.fetchall()
    
    def update_book(self, book_id, title, genre):
        """Update book details"""
        try:
            self.cursor.execute(
                'UPDATE books SET title = ?, genre = ? WHERE id = ?',
                (title, genre, book_id)
            )
            self.conn.commit()
            return True, "Book updated successfully!"
        except Exception as e:
            return False, f"Failed to update book: {str(e)}"
    
    def delete_book(self, book_id, user_id):
        """Delete a book from user's library"""
        try:
            self.cursor.execute(
                'DELETE FROM books WHERE id = ? AND user_id = ?',
                (book_id, user_id)
            )
            self.conn.commit()
            return True, "Book deleted successfully!"
        except Exception as e:
            return False, f"Failed to delete book: {str(e)}"
    
    def get_books_count(self, user_id):
        """Get total number of books for a user"""
        self.cursor.execute(
            'SELECT COUNT(*) FROM books WHERE user_id = ?',
            (user_id,)
        )
        return self.cursor.fetchone()[0]
    
    # ==================== BADGE OPERATIONS ====================
    
    def check_and_award_badges(self, user_id):
        """Check book count and award appropriate badges"""
        book_count = self.get_books_count(user_id)
        badge_milestones = [
            (5, "Bronze Reader"),
            (10, "Silver Reader"),
            (25, "Gold Reader"),
            (50, "Platinum Reader"),
            (100, "Diamond Reader")
        ]
        
        for milestone, badge_type in badge_milestones:
            if book_count >= milestone:
                # Check if badge already awarded
                self.cursor.execute(
                    'SELECT id FROM badges WHERE user_id = ? AND badge_type = ?',
                    (user_id, badge_type)
                )
                if not self.cursor.fetchone():
                    # Award new badge
                    self.cursor.execute(
                        'INSERT INTO badges (user_id, badge_type, books_count) VALUES (?, ?, ?)',
                        (user_id, badge_type, milestone)
                    )
                    self.conn.commit()
    
    def get_user_badges(self, user_id):
        """Get all badges earned by a user"""
        self.cursor.execute(
            'SELECT badge_type, books_count, earned_at FROM badges WHERE user_id = ? ORDER BY earned_at DESC',
            (user_id,)
        )
        return self.cursor.fetchall()
    
    def get_recent_badges(self, user_id, limit=3):
        """Get recently earned badges"""
        self.cursor.execute(
            'SELECT badge_type, books_count, earned_at FROM badges WHERE user_id = ? ORDER BY earned_at DESC LIMIT ?',
            (user_id, limit)
        )
        return self.cursor.fetchall()
    
    def get_next_badge(self, user_id):
        """Get the next badge to be earned"""
        book_count = self.get_books_count(user_id)
        badge_milestones = [5, 10, 25, 50, 100]
        
        for milestone in badge_milestones:
            if book_count < milestone:
                return milestone, milestone - book_count
        
        return None, 0  # All badges earned
    
    def close(self):
        """Close database connection"""
        if self.conn:
            self.conn.close()
