import customtkinter as ctk
from tkinter import messagebox
from database import Database

class DigitalLibraryApp(ctk.CTk):
    """Main application class for the Digital Library"""
    
    def __init__(self, db: Database):
        super().__init__()
        self.db = db
        self.current_user_id = None
        
        self.title("Digital Library")
        self.geometry("800x600")
        
        # Define fonts
        self.title_font = ("Arial", 24, "bold")
        self.header_font = ("Arial", 20, "bold")
        self.label_font = ("Arial", 16)
        self.button_font = ("Arial", 14)
        
        self.create_widgets()
    
    def create_widgets(self):
        """Create the main widgets for the application"""
        # Main container
        self.main_container = ctk.CTkFrame(self)
        self.main_container.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Initially, show the login/register frame
        self.show_login_frame()
    
    def show_login_frame(self):
        """Show the login/registration frame"""
        self.clear_main_container()
        login_frame = LoginFrame(self.main_container, self)
        login_frame.pack(fill="both", expand=True)
    
    def show_main_app(self):
        """Show the main application after login"""
        self.clear_main_container()
        
        # Create navigation and content frames
        self.navigation_frame = ctk.CTkFrame(self.main_container, width=150, corner_radius=10)
        self.navigation_frame.pack(side="left", fill="y", padx=(0, 10))
        
        self.content_frame = ctk.CTkFrame(self.main_container, corner_radius=10)
        self.content_frame.pack(side="right", fill="both", expand=True)
        
        # Navigation buttons
        self.home_button = ctk.CTkButton(self.navigation_frame, text="Home", font=self.button_font, command=self.show_home_frame, corner_radius=8)
        self.home_button.pack(pady=10, padx=10, fill="x")
        
        self.my_list_button = ctk.CTkButton(self.navigation_frame, text="My List", font=self.button_font, command=self.show_my_list_frame, corner_radius=8)
        self.my_list_button.pack(pady=10, padx=10, fill="x")
        
        self.badges_button = ctk.CTkButton(self.navigation_frame, text="Badges", font=self.button_font, command=self.show_badges_frame, corner_radius=8)
        self.badges_button.pack(pady=10, padx=10, fill="x")
        
        self.logout_button = ctk.CTkButton(self.navigation_frame, text="Logout", font=self.button_font, command=self.logout, corner_radius=8, fg_color="red")
        self.logout_button.pack(pady=10, padx=10, side="bottom", fill="x")
        
        # Initially show the home frame
        self.show_home_frame()
    
    def show_home_frame(self):
        """Show the home frame"""
        self.clear_content_frame()
        home_frame = HomeFrame(self.content_frame, self)
        home_frame.pack(fill="both", expand=True, padx=10, pady=10)
    
    def show_my_list_frame(self):
        """Show the my list frame"""
        self.clear_content_frame()
        my_list_frame = MyListFrame(self.content_frame, self)
        my_list_frame.pack(fill="both", expand=True, padx=10, pady=10)
    
    def show_badges_frame(self):
        """Show the badges frame"""
        self.clear_content_frame()
        badges_frame = BadgesFrame(self.content_frame, self)
        badges_frame.pack(fill="both", expand=True, padx=10, pady=10)
    
    def logout(self):
        """Logout the current user and show the login frame"""
        self.current_user_id = None
        self.show_login_frame()
    
    def clear_main_container(self):
        """Clear the main container"""
        for widget in self.main_container.winfo_children():
            widget.destroy()
    
    def clear_content_frame(self):
        """Clear the content frame"""
        for widget in self.content_frame.winfo_children():
            widget.destroy()

class LoginFrame(ctk.CTkFrame):
    """Login and registration frame"""
    
    def __init__(self, parent, app: "DigitalLibraryApp"):
        super().__init__(parent, fg_color="transparent")
        self.app = app
        
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        self.create_widgets()
    
    def create_widgets(self):
        """Create login and registration widgets"""
        container = ctk.CTkFrame(self, corner_radius=15)
        container.place(relx=0.5, rely=0.5, anchor="center")
        
        ctk.CTkLabel(container, text="Digital Library", font=self.app.title_font).pack(pady=(20, 30), padx=50)
        
        # Email
        ctk.CTkLabel(container, text="Email", font=self.app.label_font).pack(padx=20, pady=(10, 5), anchor="w")
        self.email_entry = ctk.CTkEntry(container, width=250, font=self.app.label_font)
        self.email_entry.pack(pady=5, padx=20)
        
        # Password
        ctk.CTkLabel(container, text="Password", font=self.app.label_font).pack(padx=20, pady=(10, 5), anchor="w")
        self.password_entry = ctk.CTkEntry(container, show="*", width=250, font=self.app.label_font)
        self.password_entry.pack(pady=5, padx=20)
        
        # Buttons
        button_frame = ctk.CTkFrame(container, fg_color="transparent")
        button_frame.pack(pady=30, padx=20, fill="x")
        
        ctk.CTkButton(button_frame, text="Login", font=self.app.button_font, command=self.login, corner_radius=8).pack(side="left", expand=True, padx=(0, 5))
        ctk.CTkButton(button_frame, text="Register", font=self.app.button_font, command=self.handle_registration, corner_radius=8).pack(side="right", expand=True, padx=(5, 0))
    
    def login(self):
        """Handle user login"""
        email = self.email_entry.get()
        password = self.password_entry.get()
        
        if not email or not password:
            messagebox.showerror("Error", "Please enter both email and password.")
            return
        
        success, user_id, message = self.app.db.login_user(email, password)
        
        if success:
            self.app.current_user_id = user_id
            self.app.show_main_app()
        else:
            messagebox.showerror("Login Failed", message)
    
    def handle_registration(self):
        """Handle user registration"""
        email = self.email_entry.get()
        password = self.password_entry.get()
        
        if not email or not password:
            messagebox.showerror("Error", "Please enter both email and password.")
            return
        
        success, message = self.app.db.register_user(email, password)
        
        if success:
            messagebox.showinfo("Success", message)
        else:
            messagebox.showerror("Registration Failed", message)

class HomeFrame(ctk.CTkFrame):
    """Home frame displaying user's progress"""
    
    def __init__(self, parent, app: DigitalLibraryApp):
        super().__init__(parent, fg_color="transparent")
        self.app = app
        self.create_widgets()
    
    def create_widgets(self):
        """Create widgets for the home frame"""
        ctk.CTkLabel(self, text="Home", font=self.app.header_font).pack(pady=10, anchor="w")
        
        # Recent Books
        ctk.CTkLabel(self, text="Recently Added Books", font=self.app.label_font).pack(pady=(20, 10), anchor="w")
        recent_books = self.app.db.get_recent_books(self.app.current_user_id)
        if recent_books:
            for book in recent_books:
                ctk.CTkLabel(self, text=f"- {book[1]} ({book[2]})", font=self.app.label_font).pack(anchor="w", padx=20)
        else:
            ctk.CTkLabel(self, text="No books added yet.", font=self.app.label_font).pack(anchor="w", padx=20)
        
        # Recent Badges
        ctk.CTkLabel(self, text="Recently Earned Badges", font=self.app.label_font).pack(pady=(20, 10), anchor="w")
        recent_badges = self.app.db.get_recent_badges(self.app.current_user_id)
        if recent_badges:
            for badge in recent_badges:
                ctk.CTkLabel(self, text=f"- {badge[0]} (for {badge[1]} books)", font=self.app.label_font).pack(anchor="w", padx=20)
        else:
            ctk.CTkLabel(self, text="No badges earned yet.", font=self.app.label_font).pack(anchor="w", padx=20)
        
        # Next Badge
        ctk.CTkLabel(self, text="Next Badge", font=self.app.label_font).pack(pady=(20, 10), anchor="w")
        next_milestone, books_to_go = self.app.db.get_next_badge(self.app.current_user_id)
        if next_milestone:
            ctk.CTkLabel(self, text=f"Add {books_to_go} more books to earn the next badge at {next_milestone} books.", font=self.app.label_font).pack(anchor="w", padx=20)
        else:
            ctk.CTkLabel(self, text="You have earned all the badges!", font=self.app.label_font).pack(anchor="w", padx=20)

class MyListFrame(ctk.CTkFrame):
    """Frame for managing user's book list"""
    
    def __init__(self, parent, app: DigitalLibraryApp):
        super().__init__(parent, fg_color="transparent")
        self.app = app
        self.create_widgets()
        self.load_books()
    
    def create_widgets(self):
        """Create widgets for the my list frame"""
        ctk.CTkLabel(self, text="My Book List", font=self.app.header_font).pack(pady=10, anchor="w")
        
        # Add book form
        add_book_frame = ctk.CTkFrame(self, corner_radius=10)
        add_book_frame.pack(pady=10, fill="x")
        
        ctk.CTkLabel(add_book_frame, text="Title:", font=self.app.label_font).grid(row=0, column=0, padx=(10, 5), pady=10)
        self.title_entry = ctk.CTkEntry(add_book_frame, width=200, font=self.app.label_font)
        self.title_entry.grid(row=0, column=1, padx=5, pady=10)
        
        ctk.CTkLabel(add_book_frame, text="Genre:", font=self.app.label_font).grid(row=0, column=2, padx=(10, 5), pady=10)
        self.genre_entry = ctk.CTkEntry(add_book_frame, width=150, font=self.app.label_font)
        self.genre_entry.grid(row=0, column=3, padx=5, pady=10)
        
        ctk.CTkButton(add_book_frame, text="Add Book", font=self.app.button_font, command=self.add_book, corner_radius=8).grid(row=0, column=4, padx=10, pady=10)
        
        # Book list
        self.book_list_frame = ctk.CTkScrollableFrame(self, corner_radius=10)
        self.book_list_frame.pack(fill="both", expand=True, pady=10)
    
    def load_books(self):
        """Load user's books into the list"""
        for widget in self.book_list_frame.winfo_children():
            widget.destroy()
        
        books = self.app.db.get_user_books(self.app.current_user_id)
        
        for book in books:
            book_frame = ctk.CTkFrame(self.book_list_frame, corner_radius=8)
            book_frame.pack(fill="x", pady=5, padx=5)
            
            ctk.CTkLabel(book_frame, text=f"{book[1]} ({book[2]})", font=self.app.label_font).pack(side="left", padx=10, pady=5)
            
            ctk.CTkButton(book_frame, text="Delete", font=self.app.button_font, command=lambda b=book: self.delete_book(b[0]), corner_radius=8, fg_color="red").pack(side="right", padx=5, pady=5)
            ctk.CTkButton(book_frame, text="Edit", font=self.app.button_font, command=lambda b=book: self.show_edit_book_window(b), corner_radius=8).pack(side="right", padx=5, pady=5)
    
    def add_book(self):
        """Add a new book"""
        title = self.title_entry.get()
        genre = self.genre_entry.get()
        
        if not title or not genre:
            messagebox.showerror("Error", "Please enter both title and genre.")
            return
        
        success, message = self.app.db.add_book(self.app.current_user_id, title, genre)
        
        if success:
            self.title_entry.delete(0, "end")
            self.genre_entry.delete(0, "end")
            self.load_books()
        else:
            messagebox.showerror("Error", message)
    
    def delete_book(self, book_id):
        """Delete a book"""
        if messagebox.askyesno("Confirm", "Are you sure you want to delete this book?"):
            success, message = self.app.db.delete_book(book_id, self.app.current_user_id)
            if success:
                self.load_books()
            else:
                messagebox.showerror("Error", message)
    
    def show_edit_book_window(self, book):
        """Show a window to edit a book"""
        edit_window = ctk.CTkToplevel(self)
        edit_window.title("Edit Book")
        edit_window.geometry("300x250")
        
        ctk.CTkLabel(edit_window, text="Title:", font=self.app.label_font).pack(pady=5)
        title_entry = ctk.CTkEntry(edit_window, width=250, font=self.app.label_font)
        title_entry.insert(0, book[1])
        title_entry.pack()
        
        ctk.CTkLabel(edit_window, text="Genre:", font=self.app.label_font).pack(pady=5)
        genre_entry = ctk.CTkEntry(edit_window, width=250, font=self.app.label_font)
        genre_entry.insert(0, book[2])
        genre_entry.pack()
        
        def update():
            new_title = title_entry.get()
            new_genre = genre_entry.get()
            
            if not new_title or not new_genre:
                messagebox.showerror("Error", "Please enter both title and genre.", parent=edit_window)
                return
            
            success, message = self.app.db.update_book(book[0], new_title, new_genre)
            
            if success:
                edit_window.destroy()
                self.load_books()
            else:
                messagebox.showerror("Error", message, parent=edit_window)
        
        ctk.CTkButton(edit_window, text="Update", font=self.app.button_font, command=update, corner_radius=8).pack(pady=20)

class BadgesFrame(ctk.CTkFrame):
    """Frame for displaying user's badges"""
    
    def __init__(self, parent, app: DigitalLibraryApp):
        super().__init__(parent, fg_color="transparent")
        self.app = app
        self.create_widgets()
    
    def create_widgets(self):
        """Create widgets for the badges frame"""
        ctk.CTkLabel(self, text="My Badges", font=self.app.header_font).pack(pady=10, anchor="w")
        
        badges = self.app.db.get_user_badges(self.app.current_user_id)
        
        if badges:
            for badge in badges:
                ctk.CTkLabel(self, text=f"- {badge[0]} (Earned for {badge[1]} books on {badge[2]})", font=self.app.label_font).pack(anchor="w", padx=20, pady=5)
        else:
            ctk.CTkLabel(self, text="No badges earned yet. Keep adding books!", font=self.app.label_font).pack(anchor="w", padx=20)

if __name__ == "__main__":
    # Set appearance and color theme
    ctk.set_appearance_mode("System")  # "System", "Dark", "Light"
    ctk.set_default_color_theme("green")  # "blue", "dark-blue", "green"
    
    db = Database()
    app = DigitalLibraryApp(db)
    app.mainloop()
    db.close()
